# backend/jd_generator.py
import os
import openai
from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

def generate_jd_text(job_title="Software Engineer", years_experience="2-5", must_have_skills="Python, SQL",
                     company_name="ACME Inc.", employment_type="Full-time", industry="SaaS", location="Remote",
                     use_openai=False):
    if use_openai and OPENAI_API_KEY:
        openai.api_key = OPENAI_API_KEY
        prompt = f"""Write a professional job description for:
Job Title: {job_title}
Years of Experience: {years_experience}
Must-have Skills: {must_have_skills}
Company: {company_name}
Employment Type: {employment_type}
Industry: {industry}
Location: {location}
Include summary, responsibilities (5 bullets), required qualifications (5 bullets), and nice-to-have.
"""
        try:
            resp = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role":"user","content":prompt}],
                max_tokens=600,
                temperature=0.2
            )
            jd = resp["choices"][0]["message"]["content"].strip()
            return jd
        except Exception:
            pass

    # fallback template
    skills = must_have_skills
    jd = f"""{job_title} at {company_name} ({employment_type}) — {location}

About the role:
We are looking for a {job_title} with {years_experience} years of experience in {industry}. Must-have skills: {skills}.

Responsibilities:
- Design and implement solutions related to {job_title}.
- Collaborate with cross-functional teams to deliver projects.
- Write maintainable code, tests, and documentation.
- Participate in code reviews and mentoring.
- Ensure high performance and reliability.

Required qualifications:
- {years_experience}+ years relevant experience.
- Practical experience with {skills}.
- Strong problem solving and communication skills.
- Bachelor's degree or equivalent experience.

Nice to have:
- Experience with cloud platforms, CI/CD, or domain-specific tools.
"""
    return jd
