# backend/main.py
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from utils import extract_text_from_upload
from matching import score_resumes_against_jd
from jd_generator import generate_jd_text
from email_generator import generate_interview_email, generate_rejection_email

app = FastAPI(title="Recruitment AI Agent Backend", description="FastAPI backend for Recruitment AI Agent")

# allow CORS for local frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Recruitment AI Agent Backend is running."}

@app.post("/generate_jd")
async def api_generate_jd(
    job_title: str = Form(...),
    years_experience: str = Form(...),
    must_have_skills: str = Form(""),
    company_name: str = Form(""),
    employment_type: str = Form("Full-time"),
    industry: str = Form(""),
    location: str = Form(""),
    use_openai: Optional[bool] = Form(False)
):
    jd = generate_jd_text(job_title, years_experience, must_have_skills, company_name, employment_type, industry, location, use_openai)
    return {"jd": jd}

@app.post("/match")
async def api_match(
    jd_text: Optional[str] = Form(None),
    jd_file: Optional[UploadFile] = File(None),
    resumes: List[UploadFile] = File(...)
):
    # get JD text either from uploaded file or from jd_text
    if jd_file:
        jd_text = extract_text_from_upload(jd_file)
    jd_text = jd_text or ""
    # extract resumes
    candidates = []
    for r in resumes:
        txt = extract_text_from_upload(r)
        candidates.append({"filename": r.filename, "text": txt})
    # score
    results = score_resumes_against_jd(jd_text, candidates)
    # generate emails for top and rejections (use filename as name)
    top = results[0] if results else None
    emails = {}
    if top:
        emails["interview"] = generate_interview_email(top["filename"], top["score"], jd_text, use_openai=False)
        rejection_list = []
        for r in results[1:]:
            rejection_list.append({"filename": r["filename"], "email": generate_rejection_email(r["filename"], r["remarks"], use_openai=False)})
        emails["rejections"] = rejection_list
    return JSONResponse({"results": results, "emails": emails})
