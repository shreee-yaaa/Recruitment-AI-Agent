# backend/email_generator.py
import os
import openai
from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

def generate_interview_email(candidate_filename, score, jd_text, use_openai=False):
    # Attempt to use OpenAI for nicer emails; fallback to template
    if use_openai and OPENAI_API_KEY:
        prompt = f"Write a friendly interview invitation email to {candidate_filename} for this job:\n\n{jd_text}\n\nMention the match score {score}/100 and ask for availability for a 30-45 minute interview."
        try:
            openai.api_key = OPENAI_API_KEY
            resp = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role":"user","content":prompt}],
                max_tokens=300,
                temperature=0.2
            )
            return resp["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
    return f"""Subject: Interview Invitation

Dear {candidate_filename},

We reviewed your application and were impressed. Based on our evaluation (score: {score}/100), we would like to invite you to an interview for this role.

Please reply with your availability for a 30–45 minute call over the next week.

Best regards,
Recruiting Team
"""

def generate_rejection_email(candidate_filename, feedback, use_openai=False):
    if use_openai and OPENAI_API_KEY:
        prompt = f"Write a professional rejection email to {candidate_filename}. Feedback: {feedback}"
        try:
            openai.api_key = OPENAI_API_KEY
            resp = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role":"user","content":prompt}],
                max_tokens=200,
                temperature=0.2
            )
            return resp["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
    return f"""Subject: Update on your application

Dear {candidate_filename},

Thank you for applying. After careful review, we will not be progressing your application at this time. Feedback: {feedback}

Wishing you success in your job search.
"""
