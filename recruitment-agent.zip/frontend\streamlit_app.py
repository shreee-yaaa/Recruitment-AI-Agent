# frontend/streamlit_app.py
import streamlit as st
import requests
import pandas as pd
from io import BytesIO
from typing import List, Tuple

# ----------------------
# Configuration
# ----------------------
st.set_page_config(page_title="Recruitment AI Agent (Dashboard)", layout="wide")

# default backend (editable in sidebar)
DEFAULT_BACKEND = "http://127.0.0.1:8000"

# ----------------------
# Session state init
# ----------------------
if "last_results" not in st.session_state:
    st.session_state["last_results"] = None
if "last_emails" not in st.session_state:
    st.session_state["last_emails"] = None

# ----------------------
# Helper functions
# ----------------------
def api_post_generate_jd(base_url: str, payload: dict, timeout: int = 60) -> Tuple[bool, dict]:
    try:
        r = requests.post(f"{base_url.rstrip('/')}/generate_jd", json=payload, timeout=timeout)
        if r.status_code == 200:
            return True, r.json()
        return False, {"error": f"{r.status_code} - {r.text}"}
    except Exception as e:
        return False, {"error": str(e)}


def api_post_match(base_url: str, jd_text: str = None, jd_file=None, resumes: List[BytesIO] = None, timeout: int = 120) -> Tuple[bool, dict]:
    try:
        files = []
        data = {}
        if jd_file is not None:
            files.append(("jd_file", (jd_file[0], jd_file[1])))
        elif jd_text is not None:
            data["jd_text"] = jd_text
        else:
            return False, {"error": "No JD provided"}

        if resumes:
            for fn, content in resumes:
                files.append(("resumes", (fn, content)))

        r = requests.post(f"{base_url.rstrip('/')}/match", data=data, files=files, timeout=timeout)
        if r.status_code == 200:
            return True, r.json()
        return False, {"error": f"{r.status_code} - {r.text}"}
    except Exception as e:
        return False, {"error": str(e)}


def results_to_dataframe(results: List[dict]) -> pd.DataFrame:
    rows = []
    for r in results:
        rows.append({
            "filename": r.get("filename"),
            "score": r.get("score"),
            "missing_skills": ", ".join(r.get("missing_skills", [])),
            "remarks": r.get("remarks", ""),
        })
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.sort_values(by="score", ascending=False).reset_index(drop=True)
    return df


# ----------------------
# Sidebar: global settings + JD input method
# ----------------------
with st.sidebar.form(key="settings_form"):
    st.markdown("### Backend & Settings")
    API_BASE = st.text_input("Backend URL", value=DEFAULT_BACKEND)
    st.caption("Make sure your FastAPI backend is running and CORS allows requests from the Streamlit host.")
    st.markdown("---")

    st.markdown("### Job Description Input")
    jd_method = st.radio("JD input method:", ["Manual text", "Upload file", "Generate via AI"], index=0)
    generate_use_openai = st.checkbox("When generating JD: use backend OpenAI key (if available)", value=False)
    submitted = st.form_submit_button("Apply")

# ----------------------
# Main layout: Tabs
# ----------------------
st.title("Recruitment AI Agent — Dashboard")

tabs = st.tabs(["JD & Uploads", "Evaluate & Results", "Emails & Exports", "Logs / Debug"])

# ----------------------
# Tab 1: JD & Uploads
# ----------------------
with tabs[0]:
    st.header("Prepare Job Description & Upload Resumes")
    col1, col2 = st.columns([2, 1])

    with col1:
        if jd_method == "Manual text":
            jd_text = st.text_area("Paste Job Description here", height=300, key="jd_manual")
            jd_file = None
        elif jd_method == "Upload file":
            jd_file_uploader = st.file_uploader("Upload JD (PDF/DOCX/TXT)", type=["pdf", "docx", "txt"], key="jd_file")
            jd_text = None
            jd_file = None
            if jd_file_uploader is not None:
                jd_file = (jd_file_uploader.name, jd_file_uploader.getvalue())
                st.success(f"JD file loaded: {jd_file_uploader.name}")
        else:  # Generate via AI
            st.subheader("Generate JD via backend AI")
            gen_col1, gen_col2 = st.columns(2)
            with gen_col1:
                job_title = st.text_input("Job Title", value="Senior Backend Engineer")
                years = st.text_input("Years of Experience", value="3-6")
                skills = st.text_input("Must-have skills (comma-separated)", value="Python, FastAPI, Docker")
            with gen_col2:
                company = st.text_input("Company name", value="ACME Inc.")
                emp_type = st.selectbox("Employment Type", ["Full-time", "Part-time", "Contract", "Internship"]) 
                location = st.text_input("Location", value="Remote")

            if st.button("Generate JD (call backend)"):
                payload = {
                    "job_title": job_title,
                    "years_experience": years,
                    "must_have_skills": skills,
                    "company_name": company,
                    "employment_type": emp_type,
                    "industry": "",
                    "location": location,
                    "use_openai": str(generate_use_openai)
                }
                ok, resp = api_post_generate_jd(API_BASE, payload)
                if ok:
                    jd_text = resp.get("jd", "")
                    st.success("JD generated successfully")
                    st.code(jd_text[:1000] + ("..." if len(jd_text) > 1000 else ""), language="text")
                else:
                    st.error(f"JD generation failed: {resp.get('error')}")
                    jd_text = None
            else:
                jd_text = None
                jd_file = None

    with col2:
        st.markdown("### Resumes")
        resumes = st.file_uploader("Upload up to 10 resumes (PDF/DOCX/TXT)", type=["pdf", "docx", "txt"], accept_multiple_files=True, key="resumes_uploader")
        if resumes:
            st.write(f"{len(resumes)} resume(s) uploaded")
            for r in resumes:
                st.write(f"- {r.name} — {r.type} — {r.size} bytes")

        st.markdown("---")
        st.info("After preparing JD and uploading resumes, go to the 'Evaluate & Results' tab to run scoring.")

# ----------------------
# Tab 2: Evaluate & Results
# ----------------------
with tabs[1]:
    st.header("Evaluate Candidates")
    run_col, info_col = st.columns([1, 2])
    with run_col:
        evaluate_button = st.button("Evaluate candidates and generate emails")
    with info_col:
        st.write("Click the button to send JD and resumes to the backend for scoring. Results will appear below.")

    if evaluate_button:
        if (jd_method == "Upload file" and (jd_file is None)) and (jd_method != "Upload file" and not jd_text):
            st.error("Provide JD text or upload a JD file in the 'JD & Uploads' tab first")
        elif not resumes:
            st.error("Upload resumes first")
        else:
            resumes_payload = [(f.name, f.getvalue()) for f in resumes]

            with st.spinner("Scoring resumes..."):
                ok, resp = api_post_match(API_BASE, jd_text=jd_text, jd_file=jd_file, resumes=resumes_payload)

            if not ok:
                st.error(f"Backend error: {resp.get('error')}")
            else:
                results = resp.get("results", [])
                emails = resp.get("emails", {})

                # ✅ Save to session_state for other tabs
                st.session_state["last_results"] = results
                st.session_state["last_emails"] = emails

                df = results_to_dataframe(results)
                if df.empty:
                    st.warning("No results returned from backend")
                else:
                    st.success("Scoring complete")
                    left, right = st.columns([2, 1])
                    with left:
                        st.subheader("Candidates (sorted by score)")
                        st.dataframe(df, use_container_width=True)

                        top = df.iloc[0]
                        st.markdown("---")
                        st.markdown(f"### ⭐ Top Candidate — {top['filename']} — **{top['score']} / 100**")
                        st.write("**Missing skills:**", top['missing_skills'] or "None")
                        st.write("**Remarks:**", top['remarks'] or "None")

                    with right:
                        st.subheader("Quick actions")
                        if st.download_button("Download CSV", data=df.to_csv(index=False).encode("utf-8"),
                                              file_name="results.csv", mime="text/csv"):
                            st.success("Results downloaded")

                        st.markdown("---")
                        st.subheader("Preview JD")
                        if jd_text:
                            st.text_area("Job Description Preview", jd_text, height=200)
                        elif jd_file is not None:
                            st.write(jd_file[0])
                        else:
                            st.write("No JD available")

# ----------------------
# Tab 3: Emails & Exports
# ----------------------
with tabs[2]:
    st.header("Generated Emails")
    emails = st.session_state.get("last_emails")

    if emails:
        if "interview" in emails:
            st.subheader("Interview Email (Top Candidate)")
            st.code(emails["interview"])
        if "rejections" in emails:
            st.subheader("Rejection Emails")
            for rej in emails["rejections"]:
                st.markdown(f"**{rej.get('filename')}**")
                st.code(rej.get("email"))
    else:
        st.info("No emails in memory. Run an evaluation in 'Evaluate & Results' tab first.")

# ----------------------
# Tab 4: Logs / Debug
# ----------------------
with tabs[3]:
    st.header("Logs & Debug")
    if st.button("Run a quick healthcheck"):
        try:
            r = requests.get(f"{API_BASE.rstrip('/')}/health", timeout=8)
            if r.status_code == 200:
                st.success("Backend health OK")
            else:
                st.error(f"Health check failed: {r.status_code} - {r.text}")
        except Exception as e:
            st.error(f"Healthcheck failed: {e}")
