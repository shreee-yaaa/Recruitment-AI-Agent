# 🤖 Recruitment AI Agent

An AI-powered recruitment assistant that helps HR professionals evaluate resumes against job descriptions and generate personalized interview/rejection emails.

---

## 🚀 Features
- Upload or generate **Job Descriptions (JD)**
- Upload up to **10 resumes** (PDF/DOCX)
- Automatic **resume scoring** (0–100)
- Detect **missing skills & remarks**
- Highlight **best-matched candidate**
- Generate **personalized emails**:
  - Interview call email (for best candidate)
  - Rejection email (for others)

---

## 🛠️ Tech Stack
- **Backend:** FastAPI (Python)
- **Frontend:** Streamlit Dashboard
- **AI Models:**
  - `all-MiniLM-L6-v2` (SentenceTransformers) for JD ↔ Resume semantic matching
  - GPT (or HuggingFace LLM) for generating professional emails
- **Utilities:** pdfplumber / docx for text extraction

---

## 📂 Project Structure
recruitment-agent/
├─ backend/
│ ├─ main.py # FastAPI entrypoint
│ ├─ utils.py # Helpers (text extraction, preprocessing)
│ ├─ matching.py # Resume ↔ JD matching logic
│ ├─ jd_generator.py # AI-powered JD generation
│ ├─ email_generator.py # AI-powered email generation
│ └─ requirements.txt # Backend dependencies
├─ frontend/
│ ├─ streamlit_app.py # Streamlit dashboard
│ └─ requirements.txt # Frontend dependencies
├─ examples/
│ ├─ jd_sample.txt
│ ├─ resume1.pdf
│ └─ resume2.pdf
└─ README.md

---

## ⚙️ Setup Instructions

### 1️⃣ Clone the repo:
   ```bash
   git clone https://github.com/shreee-yaaa/Recruitment-AI-Agent.git
   cd Recruitment-AI-Agent