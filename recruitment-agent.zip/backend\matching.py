# backend/matching.py
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from utils import simple_skill_parse
import math

# Load model once
MODEL_NAME = "all-MiniLM-L6-v2"
_model = None

def _get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    return _model

def _map_sim_to_score(sim):
    s = max(min(sim, 1.0), -1.0)
    return int(round((s + 1) / 2 * 100))

def score_resumes_against_jd(jd_text, candidates):
    """
    jd_text: str
    candidates: list of dicts [{"filename":..., "text":...}, ...]
    returns: list of results with filename, score (0-100), missing_skills, remarks
    """
    model = _get_model()
    jd_emb = model.encode([jd_text], convert_to_numpy=True)[0]
    jd_skills = [s.lower() for s in simple_skill_parse(jd_text)]

    results = []
    for c in candidates:
        text = c.get("text", "") or ""
        r_emb = model.encode([text], convert_to_numpy=True)[0]
        sim = float(cosine_similarity([jd_emb], [r_emb])[0][0])
        score = _map_sim_to_score(sim)
        resume_lower = text.lower()
        missing = [s for s in jd_skills if s and s not in resume_lower]
        remarks = []
        if missing:
            remarks.append("Lacks: " + ", ".join(missing[:6]))
        if score >= 85:
            remarks.append("Strong match")
        elif score >= 65:
            remarks.append("Good match but some gaps")
        else:
            remarks.append("Weak match — consider other candidates")
        results.append({
            "filename": c.get("filename"),
            "score": score,
            "similarity": sim,
            "missing_skills": missing,
            "remarks": " | ".join(remarks),
        })
    # sort descending
    results.sort(key=lambda x: x["score"], reverse=True)
    return results
