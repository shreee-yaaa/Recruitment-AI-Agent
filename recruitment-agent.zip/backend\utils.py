# backend/utils.py
import os
import tempfile
import re
from pdfminer.high_level import extract_text as pdf_extract_text
from docx import Document

def extract_text_from_pdf(path):
    try:
        return pdf_extract_text(path) or ""
    except Exception:
        return ""

def extract_text_from_docx(path):
    try:
        doc = Document(path)
        return "\n".join([p.text for p in doc.paragraphs])
    except Exception:
        return ""

def save_upload_to_temp(upload_file):
    suffix = os.path.splitext(upload_file.filename)[1]
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(upload_file.file.read())
        return tmp.name

def extract_text_from_upload(upload_file):
    """
    Accepts FastAPI UploadFile, saves to temp file, returns extracted text.
    """
    tmp_path = save_upload_to_temp(upload_file)
    ext = os.path.splitext(tmp_path)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(tmp_path)
    elif ext in (".docx", ".doc"):
        return extract_text_from_docx(tmp_path)
    else:
        try:
            with open(tmp_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return ""

def simple_skill_parse(text):
    """
    Very simple skill parsing: looks for lines with 'skills:' or comma-separated tokens.
    """
    if not text:
        return []
    text_l = text.lower()
    match = re.search(r"skills[:\-]\s*([^\n\r]+)", text_l)
    skills = set()
    if match:
        parts = re.split(r",|\||;", match.group(1))
        for p in parts:
            token = p.strip()
            if token:
                skills.add(token)
    else:
        # fallback: get tokens that look like skills
        tokens = re.findall(r"[a-zA-Z0-9\+\#\.\-]{2,}", text_l)
        stop = {"and","the","for","with","a","an","to","in","on","of","by","is","are","be","this","that","we","you","your","our","as","at","from","or","it","will"}
        for t in tokens:
            if t not in stop and not t.isdigit() and len(t) > 1:
                skills.add(t)
    return list(skills)
